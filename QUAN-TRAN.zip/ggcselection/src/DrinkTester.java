/**
 * @author: Quan Tran
 *
 */

import static org.junit.Assert.*;

import org.junit.Test;

public class DrinkTester {

	@Test
	
	public void test() {
		Drink[] dr= new Drink [10];
	
	}

}
